//wait for javascript file to be loaded
$(fusionChartsScript).load(function() {  
            FusionCharts.register("theme", {    
                        name: "XFusionTheme",
                            theme: {      
                            base: {        
                                chart: {
                                    // ADD Properties Here
                                                }      
                            }    
                        }
                    }
