//wait for javascript file to be loaded
FusionCharts.register("theme", {    
  name: "XFusionTheme",
      theme: {      
    base: {        
      chart: {
      }      
    }    
  }
});
