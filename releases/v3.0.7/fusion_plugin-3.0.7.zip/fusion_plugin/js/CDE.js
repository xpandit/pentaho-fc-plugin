var XDashFusionChartComponentAngularGauge = XDashFusionChartComponent.extend({type: "XDashFusionChartComponentAngularGauge"});
var XDashFusionChartComponentRealTimeColumn = XDashFusionChartComponent.extend({type: "XDashFusionChartComponentRealTimeColumn"});
var XDashFusionChartComponentRealTimeLine = XDashFusionChartComponent.extend({type: "XDashFusionChartComponentRealTimeLine"});
var XDashFusionChartComponentRealTimeLineDY = XDashFusionChartComponent.extend({type: "XDashFusionChartComponentRealTimeLineDY"});
var XDashFusionChartComponentRealTimeStackedArea = XDashFusionChartComponent.extend({type: "XDashFusionChartComponentRealTimeStackedArea"});