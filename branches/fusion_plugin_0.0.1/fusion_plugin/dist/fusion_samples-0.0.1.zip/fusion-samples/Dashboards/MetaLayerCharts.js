﻿var MetaLayerCharts = {
	lineChartDef: {
		width: "400",
		height: "150",
		chartType: "Line",
		cdaDataAccessId:"2"
	},
	pieChartDef: {
		width: "400",
		height: "150",
		chartType: "Pie3D",
		cdaDataAccessId:"2"
	},
	columnChartDef: {
		width: "400",
		height: "150",
		chartType: "Column3D",
		cdaDataAccessId:"2"
	},
	barChartDef: {
		width: "400",
		height: "150",
		chartType: "Bar2D",
		cdaDataAccessId:"2"
	}
};