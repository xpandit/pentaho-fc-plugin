var XDashFusionChartComponentAngularGauge = XDashFusionChartComponent.extend({type: "XDashFusionChartComponentAngularGauge"});
var XDashFusionChartComponentRealTimeColumn = XDashFusionChartComponent.extend({type: "XDashFusionChartComponentRealTimeColumn"});
var XDashFusionChartComponentRealTimeLine = XDashFusionChartComponent.extend({type: "XDashFusionChartComponentRealTimeLine"});
var XDashFusionChartComponentRealTimeLineDY = XDashFusionChartComponent.extend({type: "XDashFusionChartComponentRealTimeLineDY"});
var XDashFusionChartComponentRealTimeStackedArea = XDashFusionChartComponent.extend({type: "XDashFusionChartComponentRealTimeStackedArea"});

// XPFusionChartComponent extensions
var XDashFusionChartComponentAsync = XPFusionChartComponent.extend();
var XDashFusionChartComponentAsyncSingleSeries = XPFusionChartComponent.extend();
var XDashFusionChartComponentAsyncMultiSeries = XPFusionChartComponent.extend();
var XDashFusionChartComponentAsyncStacked = XPFusionChartComponent.extend();
var XDashFusionChartComponentAsyncCombination = XPFusionChartComponent.extend();
var XDashFusionChartComponentAsyncXYPlot = XPFusionChartComponent.extend();
var XDashFusionChartComponentAsyncScroll = XPFusionChartComponent.extend();
var XDashFusionChartComponentAsyncGauges = XPFusionChartComponent.extend();
var XDashFusionChartComponentAsyncRealTime = XPFusionChartComponent.extend();
var XDashFusionChartComponentAsyncSpark = XPFusionChartComponent.extend();
var XDashFusionChartComponentAsyncBullet = XPFusionChartComponent.extend();
var XDashFusionChartComponentAsyncOther = XPFusionChartComponent.extend();
var XDashFusionChartComponentAsyncGantt = XPFusionChartComponent.extend();
var XDashFusionChartComponentAsyncLogarithmic = XPFusionChartComponent.extend();
var XDashFusionChartComponentAsyncSpline = XPFusionChartComponent.extend();
var XDashFusionChartComponentAsyncError = XPFusionChartComponent.extend();
var XDashFusionChartComponentAsyncInverseYAxis = XPFusionChartComponent.extend();
var XDashFusionChartComponentAsyncDragAble = XPFusionChartComponent.extend();
var XDashFusionChartComponentAsyncMiscellaneous = XPFusionChartComponent.extend();
var XDashFusionChartComponentAsyncMaps = XPFusionChartComponent.extend();